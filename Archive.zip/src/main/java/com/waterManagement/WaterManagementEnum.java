package com.waterManagement;

public enum WaterManagementEnum {
	ALLOT_WATER,ADD_GUESTS,BILL;
}
